create view pvview as
  select sum(`vueblog`.`pv`.`pv`) AS `pv`, `vueblog`.`pv`.`uid` AS `uid`
  from `vueblog`.`pv`
  group by `vueblog`.`pv`.`uid`;

